CREATE PROCEDURE sp_ConsultaUsuarioPorDNI
@dni_usuario VARCHAR(10) = NULL
AS
BEGIN
    SELECT
        -- Nombre y apellido unidos
        u.name_us + ' ' + u.lastname_us AS nombre_completo,

        -- DNI del usuario
        u.dni_us AS dni_usuario,

        -- Nombre del familiar con parentesco 'M' (asumiendo que es Madre)
        (SELECT TOP 1 f.name_fam
         FROM tbl_familiares f
         WHERE f.id_fam IN (SELECT id_fam FROM tbl_user_familiares WHERE id_us = u.id_us)
           AND f.parentesco_fam = 'M') AS nombre_madre,

        -- Nombre del familiar con parentesco 'P' (asumiendo que es Padre)
        (SELECT TOP 1 f.name_fam
         FROM tbl_familiares f
         WHERE f.id_fam IN (SELECT id_fam FROM tbl_user_familiares WHERE id_us = u.id_us)
           AND f.parentesco_fam = 'P') AS nombre_padre,

        -- Fecha de ingreso de capacitación
        (SELECT TOP 1 c.fechaIngreso_cap
         FROM tbl_capacitacion c
         WHERE c.id_usu = u.id_us
         ORDER BY c.fechaIngreso_cap DESC) AS fecha_ingreso_capacitacion,

        -- Nombre del departamento del usuario
        d.name_depa AS departamento,

        -- Nombre del rol del usuario
        r.name_rol AS rol
    FROM
        tbl_user u
            LEFT JOIN
        tbl_departamento d ON u.id_dep = d.id_depa
            LEFT JOIN
        tbl_rol r ON u.id_rol = r.id_rol
    WHERE
        (@dni_usuario IS NULL OR u.dni_us = @dni_usuario)
    ORDER BY
        u.name_us, u.lastname_us;
END;
go

