CREATE PROCEDURE sp_UsuariosCapacitacionesUnificado
AS
BEGIN
    SELECT
        u.id_us,
        u.name_us + ' ' + u.lastname_us AS nombre_completo,
        u.dni_us,
        COUNT(uc.id_cu) AS total_capacitaciones,
        CASE
            WHEN COUNT(uc.id_cu) > 1 THEN 'MÁS CAPACITACIONES'
            ELSE ''
            END AS tipo,
        STUFF(
                (SELECT ', ' + c.name_cu
                 FROM tbl_usu_cu uc2
                          JOIN tbl_cursos c ON uc2.id_cu = c.id_cu
                 WHERE uc2.id_usu = u.id_us
                 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS cursos
    FROM
        tbl_user u
            INNER JOIN
        tbl_usu_cu uc ON u.id_us = uc.id_usu
    WHERE
        u.status_us = 'A'
    GROUP BY
        u.id_us, u.name_us, u.lastname_us, u.dni_us
    ORDER BY
        total_capacitaciones DESC, u.name_us, u.lastname_us;
END;
go

