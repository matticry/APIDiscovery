CREATE PROCEDURE sp_ConsultaUsuariosDetallada
AS
BEGIN
    SELECT
        -- Nombre y apellidos concatenados
        CONCAT(u.name_us, ' ', u.lastname_us) AS nombre_completo,

        -- Tipo de documento
        u.type_dni AS tipo_documento,

        -- Número de identificación
        u.dni_us AS numero_identificacion,

        -- Fecha de ingreso (de la capacitación)
        c.fechaIngreso_cap AS fecha_ingreso,

        -- Ciudad y provincia
        u.city_us AS ciudad,
        u.provincia_us AS provincia,

        -- Estado civil (no existe en el esquema proporcionado)
        'NO DISPONIBLE' AS estado_civil,

        -- Descripción del departamento
        d.name_depa AS departamento,

        -- Descripción del rol
        r.name_rol AS rol,

        -- Número de cursos tomados
        (SELECT COUNT(*) FROM tbl_usu_cu uc WHERE uc.id_usu = u.id_us) AS numero_cursos
    FROM
        tbl_user u
            LEFT JOIN
        tbl_capacitacion c ON u.id_us = c.id_usu
            LEFT JOIN
        tbl_departamento d ON u.id_dep = d.id_depa
            LEFT JOIN
        tbl_rol r ON u.id_rol = r.id_rol
    WHERE
        u.status_us = 'A'
    ORDER BY
        u.name_us, u.lastname_us;
END;
go

