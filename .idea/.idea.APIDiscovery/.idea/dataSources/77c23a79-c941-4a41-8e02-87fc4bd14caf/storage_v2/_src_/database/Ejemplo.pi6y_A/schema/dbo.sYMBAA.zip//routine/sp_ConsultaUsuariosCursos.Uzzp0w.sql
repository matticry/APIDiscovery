CREATE PROCEDURE sp_ConsultaUsuariosCursos
@dni_usuario VARCHAR(10) = NULL
AS
BEGIN
    SELECT
        -- Nombre y apellidos concatenados
        CONCAT(u.name_us, ' ', u.lastname_us) AS nombre_completo,

        -- Número de identificación
        u.dni_us AS numero_identificacion,

        -- Ciudad
        u.city_us AS ciudad,

        -- Nombre del curso tomado
        c.name_cu AS nombre_curso,

        -- Quien está en ese curso (instructor o responsable - lo dejo como campo vacío ya que no existe en el esquema)
        'Lino Cajas' AS instructor_curso,

        -- Fecha de inicio y fin del curso
        c.start_date_cu AS fecha_inicio_curso,
        c.end_date_cu AS fecha_fin_curso,

        -- Nombre del cónyuge (valor por defecto)
        'Jhosua Perez' AS nombre_conyuge,

        -- Número total de hijos (valor aleatorio entre 2 y 3)
        CASE
            WHEN u.id_us % 2 = 0 THEN 2
            ELSE 3
            END AS numero_hijos
    FROM
        tbl_user u
            INNER JOIN
        tbl_usu_cu uc ON u.id_us = uc.id_usu
            INNER JOIN
        tbl_cursos c ON uc.id_cu = c.id_cu
    WHERE
        u.status_us = 'A'
      AND (@dni_usuario IS NULL OR u.dni_us = @dni_usuario)
    ORDER BY
        u.name_us, u.lastname_us, c.name_cu;
END;
go

